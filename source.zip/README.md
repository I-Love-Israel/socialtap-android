# SocialTap Blue & White for Android

A small native Java client for SocialTap's normal-account API. Minimum Android 8
(API 26), target/compile API 36. No third-party runtime libraries and no embedded
passwords. Uses the already registered public native client and exact loopback
redirect, system browser OAuth authorization with PKCE, and Android Keystore.

## Build

The source bundle preserves the `work/` directory layout. On Windows:

1. Read the Android SDK license in `work/android-tools/repository.xml` and the
   OpenJDK distribution license. The setup script downloads official packages
   and verifies their published checksums before extracting them into `work/`.
2. Run `work/setup-android.ps1` in PowerShell.
3. Create an `outputs` directory alongside `work` if it does not already exist.
4. Run `work/test-android.ps1`, then `work/build-android.ps1`.

Build tools: Temurin JDK 21, Android platform 36, Android build-tools 36.0.0.
The build uses aapt2, javac, D8, zipalign and apksigner directly. It verifies the
finished APK's v2/v3 signatures and manifest. No Gradle/network fetch is needed
after setup. Build scripts create their temporary files within the project.

Signing keys are generated once under `work/android-tools/private-signing/`.
Protect and retain that directory for compatible upgrades. It is intentionally
excluded from source and APK distribution. A new key requires a fresh install.

## Behavior

`Api` owns and serializes token renewal across the UI and foreground service.
Access tokens and pending PKCE state are encrypted with AES-GCM/Android Keystore.
Refresh tokens rotate; ambiguous renewal failures require reconnection. A failed
connection before sending the refresh body can retry without consuming the token.
HTTPS redirects are not followed with credentials. The only HTTP endpoint is a
temporary incoming IPv4-loopback browser callback with state/issuer validation.

`MessageService` is a remoteMessaging foreground service for cross-device chat
continuity. Notification cursors survive process recreation. The first successful
sync establishes a baseline without alerting on old messages. The service is not
FCM and cannot guarantee prompt delivery during Doze, force-stop, network loss
or manufacturer battery restrictions. It never locks the phone awake.

Notification content uses a flag drawable, readable text panel and decorated
custom RemoteViews. Android 12+ supplies the surrounding template. Runtime
notification permission is requested by a visible user action. Lock-screen
public notifications omit chat identity. Notifications open the selected chat.

Attachments use the Storage Access Framework and a non-exported read-only
provider with per-URI grants. No broad storage permission is requested. Selecting
a file stages it; Send performs the API upload and message creation once. Downloads
require the server's bearer permission checks, and errors retain the text draft.

The Android release does not implement voice calls or desktop-wide idle tracking.
The inherited voice.call scope is required by the existing shared registration;
optional voice.audio is not requested. Presence reflects activity in this app.

## Checks

`tests/ChatRulesTest.java`: sender identity vs public identity, ambiguous membership,
PKCE callback state/issuer/expiry/duplicates, hidden/visible notification policy,
cursor monotonicity and unsafe filenames. Android compilation and signature checks
are separate from on-device validation; a successful build alone is not a live
SocialTap account test.
