package socialtap.bluewhite.android;
import java.util.*;
public final class ChatRulesTest {
    private static int checks=0;
    private static void check(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    private static Map<String,List<String>> callback(){Map<String,List<String>> map=new HashMap<>();map.put("state",Arrays.asList("random_state"));map.put("code",Arrays.asList("one_use_code"));map.put("iss",Arrays.asList(ApiOrigin.VALUE));return map;}
    public static void main(String[] args) {
        check(ChatRules.isMine(7,"newname",7,"oldname"),"renamed self stays right");
        check(!ChatRules.isMine(7,"self",8,"self"),"actual sender wins over matching name");
        check(ChatRules.isMine(0,"EB",0,"eb"),"legacy name fallback");
        check(!ChatRules.isMine(0,"SocialTap account",0,"SocialTap account"),"placeholder never claims others");
        check(ChatRules.uniqueMember(Arrays.asList(new HashSet<>(Arrays.asList(7L,8L)),new HashSet<>(Arrays.asList(7L,9L))))==7,"intersection confirms actual self");
        check(ChatRules.uniqueMember(Arrays.asList(new HashSet<>(Arrays.asList(7L,8L))))==0,"one ambiguous DM never guesses");
        check(ChatRules.uniqueMember(Arrays.asList(new HashSet<>(Arrays.asList(7L)),new HashSet<>(Arrays.asList(8L))))==0,"conflicting rooms never guess");
        check(ChatRules.validCallback(callback(),"random_state",1000,1500),"valid issuer and PKCE state callback");
        check(!ChatRules.validCallback(callback(),"wrong",1000,1500),"reject cross-session state");
        check(!ChatRules.validCallback(callback(),null,1000,1500),"reject unsolicited callback");
        check(!ChatRules.validCallback(callback(),"random_state",1000,601001),"reject expired sign-in");
        check(!ChatRules.validCallback(callback(),"random_state",1000,999),"reject backwards clock");
        Map<String,List<String>> q=callback();q.put("iss",Arrays.asList("https://evil.example"));check(!ChatRules.validCallback(q,"random_state",1000,1500),"reject wrong issuer");
        q=callback();q.put("code",Arrays.asList("a","b"));check(!ChatRules.validCallback(q,"random_state",1000,1500),"reject duplicate code");
        q=callback();q.put("state",Arrays.asList("random_state","random_state"));check(!ChatRules.validCallback(q,"random_state",1000,1500),"reject duplicate state");
        q=callback();q.put("code",Arrays.asList(""));check(!ChatRules.validCallback(q,"random_state",1000,1500),"reject empty code");
        q=callback();q.remove("code");q.remove("iss");q.put("error",Arrays.asList("access_denied"));check(ChatRules.validCallback(q,"random_state",1000,1500),"accept explicit denial with matching state");
        q.put("code",Arrays.asList("a"));check(!ChatRules.validCallback(q,"random_state",1000,1500),"reject ambiguous denial and code");
        check(ChatRules.notifyFor(42,42,false,1,true),"closed app receives notifications");
        check(ChatRules.notifyFor(42,99,true,1,true),"other chat receives notifications");
        check(!ChatRules.notifyFor(42,42,true,1,true),"visible chat avoids duplicate banner");
        check(!ChatRules.notifyFor(42,99,false,10,false),"initial sync avoids old-message spam");
        check(!ChatRules.notifyFor(42,99,false,0,true),"no new messages no banner");
        check(ChatRules.nextCursor(100,90)==100,"cursor never goes backwards");
        check(ChatRules.nextCursor(100,110)==110,"cursor advances after delivery");
        check(!ChatRules.filename("../../secret.txt").contains("/"),"attachment traversal stripped");
        check(!ChatRules.filename("bad\r\nheader.txt").contains("\n"),"multipart header injection stripped");
        check(ChatRules.filename("...").equals("attachment"),"empty normalized filename has fallback");
        System.out.println("PASS: "+checks+" Android policy and security checks");
    }
}
