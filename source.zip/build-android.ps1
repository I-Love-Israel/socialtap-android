$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'socialtap-client/android'
$toolsRoot = Join-Path $PSScriptRoot 'android-tools'
$javaRoot = (Get-ChildItem (Join-Path $toolsRoot 'jdk') -Directory | Select-Object -First 1).FullName
$buildTools = Join-Path $toolsRoot 'build-tools/android-16'
$androidJar = Join-Path $toolsRoot 'platform/android-36/android.jar'
$buildRoot = Join-Path $PSScriptRoot 'android-build'
$output = Join-Path (Split-Path $PSScriptRoot -Parent) 'outputs/SocialTap.apk'
foreach ($folder in @($buildRoot,(Join-Path $buildRoot 'generated'),(Join-Path $buildRoot 'classes'),(Join-Path $buildRoot 'dex'))) { New-Item -ItemType Directory -Force -Path $folder | Out-Null }
$env:JAVA_HOME = $javaRoot
$env:PATH = (Join-Path $javaRoot 'bin') + ';' + $env:PATH
$buildTemp = Join-Path $buildRoot 'temp'
New-Item -ItemType Directory -Force -Path $buildTemp | Out-Null
$env:JAVA_TOOL_OPTIONS = '-Djava.io.tmpdir="' + $buildTemp + '"'
$env:TEMP = $buildTemp
$env:TMP = $buildTemp
function Check-Exit($step) { if ($LASTEXITCODE -ne 0) { throw "$step failed ($LASTEXITCODE)" } }
& (Join-Path $buildTools 'aapt2.exe') compile --dir (Join-Path $project 'res') -o (Join-Path $buildRoot 'resources.zip')
Check-Exit 'Resource compilation'
& (Join-Path $buildTools 'aapt2.exe') link -o (Join-Path $buildRoot 'unsigned.apk') -I $androidJar --manifest (Join-Path $project 'AndroidManifest.xml') --java (Join-Path $buildRoot 'generated') (Join-Path $buildRoot 'resources.zip')
Check-Exit 'Resource linking'
$sources = @(Get-ChildItem (Join-Path $project 'src'),(Join-Path $buildRoot 'generated') -Filter '*.java' -Recurse | ForEach-Object { $_.FullName })
& (Join-Path $javaRoot 'bin/javac.exe') --release 8 -encoding UTF-8 -classpath $androidJar -d (Join-Path $buildRoot 'classes') @sources
Check-Exit 'Java compilation'
& (Join-Path $javaRoot 'bin/jar.exe') cf (Join-Path $buildRoot 'classes.jar') -C (Join-Path $buildRoot 'classes') .
Check-Exit 'Class packaging'
& (Join-Path $buildTools 'd8.bat') --release --min-api 26 --lib $androidJar --output (Join-Path $buildRoot 'dex') (Join-Path $buildRoot 'classes.jar')
Check-Exit 'DEX compilation'
& (Join-Path $javaRoot 'bin/jar.exe') uf (Join-Path $buildRoot 'unsigned.apk') -C (Join-Path $buildRoot 'dex') classes.dex
Check-Exit 'APK packaging'
& (Join-Path $buildTools 'zipalign.exe') -f -p 4 (Join-Path $buildRoot 'unsigned.apk') (Join-Path $buildRoot 'aligned.apk')
Check-Exit 'APK alignment'
$signing = Join-Path $toolsRoot 'private-signing'
New-Item -ItemType Directory -Force -Path $signing | Out-Null
$passwordFile = Join-Path $signing 'password.txt'
if (-not (Test-Path -LiteralPath $passwordFile)) { $random = New-Object byte[] 32; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($random); [System.IO.File]::WriteAllText($passwordFile,[Convert]::ToBase64String($random)) }
$env:SOCIALTAP_SIGNING_PASSWORD = [System.IO.File]::ReadAllText($passwordFile)
$keystore = Join-Path $signing 'socialtap-release.p12'
if (-not (Test-Path -LiteralPath $keystore)) {
    & (Join-Path $javaRoot 'bin/keytool.exe') -genkeypair -keystore $keystore -storetype PKCS12 -storepass:env SOCIALTAP_SIGNING_PASSWORD -keypass:env SOCIALTAP_SIGNING_PASSWORD -alias socialtap -keyalg RSA -keysize 3072 -validity 10000 -dname 'CN=SocialTap Blue and White, OU=Personal Android Client'
    Check-Exit 'Signing key creation'
}
& (Join-Path $buildTools 'apksigner.bat') sign --ks $keystore --ks-key-alias socialtap --ks-pass env:SOCIALTAP_SIGNING_PASSWORD --key-pass env:SOCIALTAP_SIGNING_PASSWORD --out $output (Join-Path $buildRoot 'aligned.apk')
Check-Exit 'APK signing'
Remove-Item Env:SOCIALTAP_SIGNING_PASSWORD
& (Join-Path $buildTools 'apksigner.bat') verify --verbose $output
Check-Exit 'Signature verification'
& (Join-Path $buildTools 'aapt2.exe') dump badging $output
Check-Exit 'Manifest verification'
Write-Output "Built $output"
