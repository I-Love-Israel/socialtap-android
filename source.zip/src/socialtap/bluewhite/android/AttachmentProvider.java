package socialtap.bluewhite.android;

import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import java.io.*;

/** Only private cached attachment files can be opened, with a per-URI temporary grant. */
public final class AttachmentProvider extends ContentProvider {
    @Override public boolean onCreate(){return true;}
    private File file(Uri uri) throws FileNotFoundException {
        try{File root=new File(getContext().getCacheDir(),"attachments").getCanonicalFile();File result=new File(root,uri.getLastPathSegment()==null?"":uri.getLastPathSegment()).getCanonicalFile();if(!result.getParentFile().equals(root)||!result.isFile())throw new IOException();return result;}catch(Exception e){throw new FileNotFoundException("Attachment unavailable");}
    }
    @Override public String getType(Uri uri) {String name=uri.getLastPathSegment();String extension=name==null||!name.contains(".")?"":name.substring(name.lastIndexOf('.')+1).toLowerCase(java.util.Locale.ROOT);String type=MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);return type==null?"application/octet-stream":type;}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {if(!mode.equals("r"))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort) {try{File file=file(uri);String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor cursor=new MatrixCursor(columns,1);Object[] row=new Object[columns.length];for(int i=0;i<columns.length;i++)row[i]=columns[i].equals(OpenableColumns.SIZE)?file.length():columns[i].equals(OpenableColumns.DISPLAY_NAME)?file.getName().replaceFirst("^[a-f0-9-]+_",""):null;cursor.addRow(row);return cursor;}catch(Exception e){return null;}}
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException();}
}
