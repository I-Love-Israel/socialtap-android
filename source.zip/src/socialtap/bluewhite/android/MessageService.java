package socialtap.bluewhite.android;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.net.*;
import android.os.*;
import android.widget.RemoteViews;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public final class MessageService extends Service {
    public static volatile boolean screenVisible=false;
    public static volatile long visibleChat=-1,lastTouch=System.currentTimeMillis();
    public static volatile String connectionStatus="";
    private final ScheduledExecutorService worker=Executors.newSingleThreadScheduledExecutor();
    private Api api;
    private volatile ServerSocket callbackServer;
    private volatile boolean accepting=false,destroyed=false;
    private long lastPresence=0;
    private ConnectivityManager.NetworkCallback networkCallback;
    public static void start(Context context) { context.startForegroundService(new Intent(context,MessageService.class)); }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate();api=Api.get(this);channels(this);
        Notification ongoing=ongoing("Keeping your chats connected");
        if(Build.VERSION.SDK_INT>=34)startForeground(1,ongoing,ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING);else startForeground(1,ongoing);
        worker.scheduleWithFixedDelay(this::tick,0,8,TimeUnit.SECONDS);
        try {
            networkCallback=new ConnectivityManager.NetworkCallback(){@Override public void onAvailable(Network network){if(!destroyed)worker.execute(MessageService.this::tick);}};
            getSystemService(ConnectivityManager.class).registerDefaultNetworkCallback(networkCallback);
        }catch(Exception ignored){}
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(api.pending())listenForSignIn();return START_STICKY;
    }
    private void tick() {
        if(destroyed)return;
        try {
            if(!api.connected()) {
                if(api.pending()){listenForSignIn();setStatus("Finish sign-in in your browser");}else {setStatus(api.status().isEmpty()?"Open SocialTap to connect":api.status());stopSelf();}
                return;
            }
            if(!api.prefs().getBoolean("background",true)){stopSelf();return;}
            boolean initialized=api.prefs().contains("notification_cursor");long cursor=api.prefs().getLong("notification_cursor",0);
            JSONObject result=(JSONObject)api.getJson("/api/notifications?since="+cursor);
            JSONArray updates=result.optJSONArray("updates");
            if(updates!=null)for(int i=0;i<updates.length();i++){
                JSONObject row=updates.getJSONObject(i);long chat=row.optLong("chat_id",0),count=row.optLong("new_messages");
                if(ChatRules.notifyFor(chat,visibleChat,screenVisible,count,initialized))showMessage(this,chat,api.prefs().getString("chat_name_"+chat,chat==0?"Global Chat":"New message"),count+" new message"+(count==1?"":"s"),false);
            }
            api.prefs().edit().putLong("notification_cursor",ChatRules.nextCursor(cursor,result.optLong("since"))).apply();
            if(api.hasScope("presence.write")&&System.currentTimeMillis()-lastPresence>60000) {
                lastPresence=System.currentTimeMillis();
                JSONObject presence=api.postJson("/api/user/presence",new JSONObject().put("idle_seconds",Math.min(2147483647L,Math.max(0,(System.currentTimeMillis()-lastTouch)/1000))));
                api.identity(presence.optLong("user_id"),null);
            }
            setStatus("Connected · receiving messages");
        }catch(Exception error){setStatus(api.status().isEmpty()?"Waiting for connection · will retry":api.status());}
    }
    private void setStatus(String value) {
        if(destroyed||value.equals(connectionStatus))return;connectionStatus=value;
        getSystemService(NotificationManager.class).notify(1,ongoing(value));
    }
    private Notification ongoing(String text) {
        return new Notification.Builder(this,"connection").setSmallIcon(R.drawable.ic_notification).setContentTitle("SocialTap is running").setContentText(text).setContentIntent(open(this,-1)).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false).setCategory(Notification.CATEGORY_SERVICE).build();
    }
    public static void channels(Context context) {
        NotificationManager manager=context.getSystemService(NotificationManager.class);
        NotificationChannel messages=new NotificationChannel("messages","New messages",NotificationManager.IMPORTANCE_HIGH);messages.setDescription("SocialTap messages with an Israeli-flag background");messages.enableVibration(true);messages.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        manager.createNotificationChannel(messages);
        NotificationChannel connection=new NotificationChannel("connection","Background connection",NotificationManager.IMPORTANCE_LOW);connection.setDescription("Keeps SocialTap receiving messages when its screen is closed");connection.setShowBadge(false);manager.createNotificationChannel(connection);
    }
    private static PendingIntent open(Context context,long chat) {
        Intent intent=new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.setData(Uri.parse("socialtap-bluewhite://notification/"+chat));intent.putExtra("chat_id",chat);
        return PendingIntent.getActivity(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static boolean showMessage(Context context,long chat,String title,String body,boolean test) {
        channels(context);NotificationManager manager=context.getSystemService(NotificationManager.class);
        if(!manager.areNotificationsEnabled())return false;
        NotificationChannel channel=manager.getNotificationChannel("messages");if(channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;
        RemoteViews content=new RemoteViews(context.getPackageName(),R.layout.notification_flag);content.setTextViewText(R.id.notification_title,title);content.setTextViewText(R.id.notification_body,body);
        Notification publicVersion=new Notification.Builder(context,"messages").setSmallIcon(R.drawable.ic_notification).setContentTitle("SocialTap").setContentText("New message").build();
        Notification notification=new Notification.Builder(context,"messages").setSmallIcon(R.drawable.ic_notification).setColor(0xff1457c8).setContentTitle(title).setContentText(body).setCustomContentView(content).setCustomBigContentView(content).setCustomHeadsUpContentView(content).setStyle(new Notification.DecoratedCustomViewStyle()).setContentIntent(open(context,chat)).setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(publicVersion).build();
        try{manager.notify(test?"test":"chat:"+chat,2,notification);return true;}catch(SecurityException ignored){return false;}
    }
    private synchronized void listenForSignIn() {
        if(accepting||destroyed)return;accepting=true;
        new Thread(()->{
            try(ServerSocket server=new ServerSocket()) {
                server.setReuseAddress(true);server.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),4317));server.setSoTimeout(1000);callbackServer=server;
                while(!destroyed&&api.pending()) {
                    try(Socket socket=server.accept()) {
                        socket.setSoTimeout(10000);
                        BufferedReader reader=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.US_ASCII));
                        String first=reader.readLine();String host="";int total=first==null?0:first.length();String line;
                        while((line=reader.readLine())!=null&&!line.isEmpty()){total+=line.length();if(total>16384)throw new IOException("Request too long");if(line.toLowerCase(Locale.ROOT).startsWith("host:"))host=line.substring(5).trim();}
                        boolean valid=false;String detail="Sign-in link was not accepted. Return to SocialTap and try again.";
                        if(first!=null&&first.length()<8192&&host.equals("127.0.0.1:4317")) {
                            String[] parts=first.split(" ");
                            if(parts.length==3&&parts[0].equals("GET")) {
                                Uri uri=Uri.parse(parts[1]);
                                if(uri.getPath().equals("/oauth/callback")) {
                                    Map<String,List<String>> query=new HashMap<>();for(String name:uri.getQueryParameterNames())query.put(name,uri.getQueryParameters(name));
                                    try{valid=api.acceptCallback(query);if(valid)detail=api.connected()?"You are connected. Return to SocialTap to see your chats.":"Sign-in was cancelled. Return to SocialTap to try again.";}catch(Exception error){detail="Sign-in could not finish. Return to SocialTap and reconnect.";}
                                }
                            }
                        }
                        String html="<!doctype html><meta name='viewport' content='width=device-width,initial-scale=1'><title>SocialTap</title><body style='background:#101827;color:#edf4ff;font:18px system-ui;padding:32px'><h1>SocialTap</h1><p>"+detail+"</p><p><a style='color:#9fc5ff' href='socialtap-bluewhite://connected'>Return to SocialTap</a></p>";
                        byte[] body=html.getBytes(StandardCharsets.UTF_8);OutputStream out=socket.getOutputStream();out.write(((valid?"HTTP/1.1 200 OK":"HTTP/1.1 400 Bad Request")+"\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nContent-Security-Policy: default-src 'none'; style-src 'unsafe-inline'\r\nContent-Length: "+body.length+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));out.write(body);out.flush();
                        if(valid){worker.execute(this::tick);break;}
                    } catch(SocketTimeoutException ignored){}
                }
            }catch(Exception error){if(!destroyed)setStatus("Could not receive sign-in. Reopen SocialTap and try again.");}
            finally{callbackServer=null;accepting=false;}
        },"SocialTap browser sign-in").start();
    }
    @Override public void onDestroy() {
        destroyed=true;worker.shutdownNow();try{if(callbackServer!=null)callbackServer.close();}catch(IOException ignored){}
        if(networkCallback!=null)try{getSystemService(ConnectivityManager.class).unregisterNetworkCallback(networkCallback);}catch(Exception ignored){}
        connectionStatus="";super.onDestroy();
    }
}
