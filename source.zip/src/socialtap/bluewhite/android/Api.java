package socialtap.bluewhite.android;

import android.content.*;
import android.security.keystore.*;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.HttpsURLConnection;

/** One token owner for both the screen and background service; refresh is serialized. */
public final class Api {
    private static Api instance;
    public static synchronized Api get(Context context) { if(instance==null) instance=new Api(context.getApplicationContext()); return instance; }
    private final Context context;
    private JSONObject session=new JSONObject();
    private volatile String problem="", ownName="SocialTap account", grantedScopes="";
    private volatile boolean isConnected=false;
    private volatile long ownId=0,pendingCreated=0;
    public static final int MAX_FILE=10*1024*1024;
    private Api(Context ctx) {
        context=ctx;
        try {
            String blob=prefs().getString("encrypted_session","");
            if(!blob.isEmpty()) {
                byte[] bytes=Base64.decode(blob,Base64.NO_WRAP);
                Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Arrays.copyOf(bytes,12)));
                session=new JSONObject(new String(cipher.doFinal(Arrays.copyOfRange(bytes,12,bytes.length)),StandardCharsets.UTF_8));
            }
        } catch(Exception e) { problem="Please sign in again on this device."; }
        snapshot();
    }
    public SharedPreferences prefs() { return context.getSharedPreferences("socialtap",Context.MODE_PRIVATE); }
    private SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias("socialtap_session")) return (SecretKey)store.getKey("socialtap_session",null);
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder("socialtap_session",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return gen.generateKey();
    }
    private void save() throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=cipher.doFinal(session.toString().getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();bytes.write(cipher.getIV());bytes.write(encrypted);
        if(!prefs().edit().putString("encrypted_session",Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP)).commit()) throw new IOException("Could not save your connection.");
        snapshot();
    }
    private void snapshot(){isConnected=!session.optString("access").isEmpty();ownId=session.optLong("self_id");ownName=session.optString("self_name","SocialTap account");grantedScopes=session.optString("scope");pendingCreated=session.optLong("pending_created");}
    public boolean connected() { return isConnected; }
    public String status() { return problem; }
    public long selfId() { return ownId; }
    public String selfName() { return ownName; }
    public synchronized void identity(long id,String name) throws Exception {
        if(id<=0) return;
        if(selfId()==id && (name==null||name.isEmpty()||name.equals(selfName()))) return;
        session.put("self_id",id); if(name!=null&&!name.isEmpty())session.put("self_name",name);save();
    }
    public synchronized void learnMessage(JSONObject msg) throws Exception { if(msg!=null)identity(msg.optLong("sender_user_id"),msg.optString("profile_username",msg.optString("username"))); }
    private static String random() { byte[] bytes=new byte[32];new SecureRandom().nextBytes(bytes);return Base64.encodeToString(bytes,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING); }
    public synchronized String beginAuth() throws Exception {
        String verifier=random(),state=random();
        session.put("pending_state",state).put("pending_verifier",verifier).put("pending_created",System.currentTimeMillis());save();
        String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)),Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING);
        return ApiOrigin.VALUE+"/api/oauth/authorize?"+form("response_type","code","client_id",ApiOrigin.CLIENT_ID,"redirect_uri",ApiOrigin.REDIRECT,"scope","chat.read chat.send voice.call account.read presence.write","state",state,"code_challenge",challenge,"code_challenge_method","S256");
    }
    public boolean pending() { return pendingCreated>0&&System.currentTimeMillis()-pendingCreated<600000; }
    public synchronized boolean acceptCallback(Map<String,List<String>> query) throws Exception {
        if(!ChatRules.validCallback(query,session.optString("pending_state",null),session.optLong("pending_created"),System.currentTimeMillis())) return false;
        String verifier=session.optString("pending_verifier");
        session.remove("pending_state");session.remove("pending_verifier");session.remove("pending_created");save();
        if(query.containsKey("error")) { problem="Sign-in was cancelled. You can try again.";return true; }
        JSONObject token=new JSONObject(new String(request("POST","/api/oauth/token",form("grant_type","authorization_code","client_id",ApiOrigin.CLIENT_ID,"code",query.get("code").get(0),"redirect_uri",ApiOrigin.REDIRECT,"code_verifier",verifier).getBytes(StandardCharsets.UTF_8),"application/x-www-form-urlencoded",null),StandardCharsets.UTF_8));
        session=new JSONObject();tokens(token);prefs().edit().remove("notification_cursor").putBoolean("background",true).apply();return true;
    }
    private void tokens(JSONObject response) throws Exception {
        if(response.optString("access_token").isEmpty()||response.optString("refresh_token").isEmpty()||!"bearer".equalsIgnoreCase(response.optString("token_type"))||response.optLong("expires_in")<=0) throw new IOException("SocialTap returned an incomplete sign-in. Please reconnect.");
        session.put("access",response.getString("access_token")).put("refresh",response.getString("refresh_token")).put("expires",System.currentTimeMillis()+response.getLong("expires_in")*1000).put("scope",response.optString("scope"));
        session.remove("refresh_uncertain");problem="";save();
    }
    private String access() throws Exception {
        if(!connected()) throw new IOException("Connect to SocialTap first.");
        if(session.optBoolean("refresh_uncertain")) throw new IOException("Please reconnect: SocialTap could not confirm renewal of this sign-in.");
        if(System.currentTimeMillis()<session.optLong("expires")-60000) return session.getString("access");
        android.net.ConnectivityManager network=context.getSystemService(android.net.ConnectivityManager.class);
        android.net.NetworkCapabilities capabilities=network.getNetworkCapabilities(network.getActiveNetwork());
        if(capabilities==null||!capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET))throw new IOException("Waiting for an internet connection.");
        // Persist before dispatch. Never reuse a rotating refresh token after an ambiguous failure.
        session.put("refresh_uncertain",true);save();
        try {
            JSONObject next=new JSONObject(new String(request("POST","/api/oauth/token",form("grant_type","refresh_token","client_id",ApiOrigin.CLIENT_ID,"refresh_token",session.getString("refresh")).getBytes(StandardCharsets.UTF_8),"application/x-www-form-urlencoded",null),StandardCharsets.UTF_8));
            tokens(next);
        } catch(Exception e) {
            if(e instanceof TransportFailure && !((TransportFailure)e).sent){session.remove("refresh_uncertain");save();throw e;}
            problem="Please reconnect: your sign-in could not be renewed safely.";throw new IOException(problem);
        }
        return session.getString("access");
    }
    public boolean hasScope(String scope) { return Arrays.asList(grantedScopes.split(" ")).contains(scope); }
    public synchronized Object getJson(String path) throws Exception { return new JSONTokener(new String(request("GET",path,null,null,access()),StandardCharsets.UTF_8)).nextValue(); }
    public synchronized JSONObject postJson(String path,JSONObject value) throws Exception { return new JSONObject(new String(request("POST",path,value.toString().getBytes(StandardCharsets.UTF_8),"application/json",access()),StandardCharsets.UTF_8)); }
    public synchronized JSONObject send(long chat,String message) throws Exception {
        JSONObject result=new JSONObject(new String(request("POST","/send",form("chat_id",Long.toString(chat),"message",message).getBytes(StandardCharsets.UTF_8),"application/x-www-form-urlencoded",access()),StandardCharsets.UTF_8));learnMessage(result.optJSONObject("message"));return result;
    }
    public synchronized JSONObject upload(long chat,String name,byte[] file,String caption) throws Exception {
        if(file.length==0||file.length>MAX_FILE) throw new IOException("Choose a nonempty file up to 10 MiB.");
        String boundary="SocialTap"+random();ByteArrayOutputStream body=new ByteArrayOutputStream();
        body.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n"+chat+"\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"message\"\r\n\r\n"+caption+"\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+ChatRules.filename(name)+"\"\r\nContent-Type: application/octet-stream\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        body.write(file);body.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.US_ASCII));
        JSONObject result=new JSONObject(new String(request("POST","/attachments",body.toByteArray(),"multipart/form-data; boundary="+boundary,access()),StandardCharsets.UTF_8));learnMessage(result.optJSONObject("message"));return result;
    }
    public synchronized byte[] attachment(String id) throws Exception {
        if(!id.matches("[A-Za-z0-9_-]{1,160}")) throw new IOException("This attachment link is invalid.");
        return request("GET","/attachments/"+id,null,null,access());
    }
    public synchronized void disconnect() throws Exception {
        if(connected()) request("POST","/api/oauth/revoke",form("client_id",ApiOrigin.CLIENT_ID,"token",session.optString("refresh")).getBytes(StandardCharsets.UTF_8),"application/x-www-form-urlencoded",null);
        session=new JSONObject();save();prefs().edit().remove("notification_cursor").putBoolean("background",false).apply();problem="";
    }
    public static String form(String... pairs) throws UnsupportedEncodingException {
        StringBuilder out=new StringBuilder();for(int i=0;i<pairs.length;i+=2){if(out.length()>0)out.append('&');out.append(URLEncoder.encode(pairs[i],"UTF-8")).append('=').append(URLEncoder.encode(pairs[i+1],"UTF-8"));}return out.toString();
    }
    private byte[] request(String method,String path,byte[] body,String type,String token) throws Exception {
        if(!path.startsWith("/")||path.startsWith("//")||path.indexOf('\r')>=0||path.indexOf('\n')>=0) throw new IOException("Invalid API path.");
        HttpsURLConnection conn=(HttpsURLConnection)new URL(ApiOrigin.VALUE+path).openConnection();
        conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(15000);conn.setReadTimeout(25000);conn.setRequestMethod(method);conn.setRequestProperty("Accept","application/json");conn.setRequestProperty("User-Agent","SocialTap-BlueWhite-Android/1.0");
        if(token!=null)conn.setRequestProperty("Authorization","Bearer "+token);
        boolean sent=false;
        try {
            if(body!=null){conn.setDoOutput(true);conn.setRequestProperty("Content-Type",type);conn.setFixedLengthStreamingMode(body.length);try(OutputStream out=conn.getOutputStream()){sent=true;out.write(body);}}
            int status=conn.getResponseCode();byte[] bytes;
            try(InputStream stream=status>=200&&status<300?conn.getInputStream():conn.getErrorStream()){bytes=readLimited(stream,MAX_FILE+1024*1024);}
            if(status<200||status>=300){String message="SocialTap request failed ("+status+").";try{JSONObject error=new JSONObject(new String(bytes,StandardCharsets.UTF_8));message=error.optString("error_description",error.optString("error",message));}catch(Exception ignored){}throw new IOException(message);}
            return bytes;
        } catch(IOException e){throw new TransportFailure(e.getMessage(),sent);} finally {conn.disconnect();}
    }
    private static final class TransportFailure extends IOException { final boolean sent;TransportFailure(String message,boolean value){super(message);sent=value;} }
    public static byte[] readLimited(InputStream stream,int limit) throws IOException {
        if(stream==null)return new byte[0];ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[16384];int n;
        while((n=stream.read(buffer))!=-1){if(out.size()+n>limit)throw new IOException("This file is too large (10 MiB maximum).");out.write(buffer,0,n);}return out.toByteArray();
    }
}
