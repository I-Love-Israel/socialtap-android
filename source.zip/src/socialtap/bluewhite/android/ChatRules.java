package socialtap.bluewhite.android;

import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Pure policy shared by the app and the JVM regression checks. */
public final class ChatRules {
    private ChatRules() {}
    public static boolean isMine(long selfId, String selfName, long senderId, String profileName) {
        if (selfId > 0 && senderId > 0) return selfId == senderId;
        return selfName != null && !selfName.isEmpty() && !selfName.equals("SocialTap account") && selfName.equalsIgnoreCase(profileName);
    }
    public static long uniqueMember(List<Set<Long>> rooms) {
        Set<Long> candidates = null;
        for (Set<Long> room : rooms) {
            if (room.isEmpty()) continue;
            if (candidates == null) candidates = new HashSet<>(room); else candidates.retainAll(room);
        }
        return candidates != null && candidates.size() == 1 ? candidates.iterator().next() : 0;
    }
    public static boolean validCallback(Map<String,List<String>> q, String state, long created, long now) {
        if (state == null || created <= 0 || now < created || now-created > 600000) return false;
        for (List<String> values : q.values()) if (values.size() != 1) return false;
        if (!MessageDigest.isEqual(state.getBytes(StandardCharsets.UTF_8), value(q,"state").getBytes(StandardCharsets.UTF_8))) return false;
        if (q.containsKey("error")) return !q.containsKey("code");
        return ApiOrigin.VALUE.equals(value(q,"iss")) && !value(q,"code").isEmpty();
    }
    private static String value(Map<String,List<String>> q, String key) { List<String> v=q.get(key); return v==null||v.isEmpty()?"":v.get(0); }
    public static boolean notifyFor(long chat, long visibleChat, boolean visible, long count, boolean initialized) {
        return initialized && count > 0 && !(visible && chat == visibleChat);
    }
    public static long nextCursor(long previous, long received) { return Math.max(previous,received); }
    public static String filename(String raw) {
        if (raw == null) raw="attachment";
        String clean=raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").replaceAll("^[. ]+|[. ]+$","");
        return clean.isEmpty()?"attachment":clean.substring(0,Math.min(120,clean.length()));
    }
}
