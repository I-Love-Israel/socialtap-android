package socialtap.bluewhite.android;
public final class ApiOrigin {
    public static final String VALUE="https://www.socialtap.social";
    // A public native client. This is an identifier, never a client secret.
    public static final String CLIENT_ID="stu_LiuJtKyxFx69AXy1uceZw_jrxTyKjqPh9-PP3fSS9S8";
    public static final String REDIRECT="http://127.0.0.1:4317/oauth/callback";
}
