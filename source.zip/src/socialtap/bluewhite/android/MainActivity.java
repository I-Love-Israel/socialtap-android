package socialtap.bluewhite.android;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private Api api;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private LinearLayout root,body,messageList;
    private ScrollView messageScroll;
    private TextView status,attachmentLabel;
    private EditText composer;
    private Button send;
    private JSONArray chats=new JSONArray(),messages=new JSONArray();
    private long chat=-1,lastChats=0,readCursor=0;
    private String chatName="",rendered="",selectedName="";
    private byte[] selectedFile,pendingSave;
    private boolean dark=true,polling=false,sending=false,resumed=false,wasConnected=false,profileChecked=false;
    private int bg,card,ink,muted,accent;
    private final Runnable pollTask=new Runnable(){public void run(){if(resumed){poll();main.postDelayed(this,4000);}}};
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);api=Api.get(this);dark=api.prefs().getBoolean("dark",true);wasConnected=api.connected();
        chat=getIntent().getLongExtra("chat_id",state==null?-1:state.getLong("chat",-1));
        if(chat>=0)chatName=api.prefs().getString("chat_name_"+chat,chat==0?"Global Chat":"Conversation");
        rebuild();
        if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::goBack);
    }
    @Override public void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);long requested=intent.getLongExtra("chat_id",-1);if(requested>=0)openChat(requested,api.prefs().getString("chat_name_"+requested,requested==0?"Global Chat":"Conversation"));}
    @Override public void onSaveInstanceState(Bundle state){saveDraft();state.putLong("chat",chat);super.onSaveInstanceState(state);}
    @Override public void onResume(){super.onResume();resumed=true;MessageService.screenVisible=true;MessageService.visibleChat=chat;MessageService.lastTouch=System.currentTimeMillis();if((api.connected()&&api.prefs().getBoolean("background",true))||api.pending())MessageService.start(this);main.removeCallbacks(pollTask);main.post(pollTask);}
    @Override public void onPause(){saveDraft();resumed=false;MessageService.screenVisible=false;main.removeCallbacks(pollTask);super.onPause();}
    @Override public void onDestroy(){worker.shutdownNow();super.onDestroy();}
    @Override public boolean dispatchTouchEvent(android.view.MotionEvent event){MessageService.lastTouch=System.currentTimeMillis();return super.dispatchTouchEvent(event);}
    @Override public void onBackPressed(){goBack();}
    private void goBack(){if(chat>=0){saveDraft();chat=-1;MessageService.visibleChat=-1;selectedFile=null;rebuild();poll();}else moveTaskToBack(true);}
    private int dp(float size){return Math.round(size*getResources().getDisplayMetrics().density);}
    private void colors(){bg=Color.parseColor(dark?"#101827":"#F4F7FD");card=Color.parseColor(dark?"#1A2940":"#FFFFFF");ink=Color.parseColor(dark?"#EDF4FF":"#142746");muted=Color.parseColor(dark?"#ADBDD5":"#50617D");accent=Color.parseColor(dark?"#8BB8FF":"#1754BC");}
    private GradientDrawable rounded(int color,int radius){GradientDrawable drawable=new GradientDrawable();drawable.setColor(color);drawable.setCornerRadius(dp(radius));return drawable;}
    private TextView text(String value,int size,int color){TextView label=new TextView(this);label.setText(value);label.setTextSize(size);label.setTextColor(color);return label;}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(ink);b.setMinHeight(dp(48));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(card));b.setOnClickListener(v->action.run());return b;}
    private LinearLayout vertical(){LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);return view;}
    private LinearLayout horizontal(){LinearLayout view=new LinearLayout(this);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
    private void space(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void rebuild(){
        colors();rendered="";composer=null;messageList=null;root=vertical();root.setBackgroundColor(bg);root.setFitsSystemWindows(false);
        root.setOnApplyWindowInsetsListener((view,insets)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.ime());view.setPadding(bars.left,bars.top,bars.right,bars.bottom);}else view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});
        setContentView(root);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);
        if(Build.VERSION.SDK_INT>=30&&getWindow().getInsetsController()!=null)getWindow().getInsetsController().setSystemBarsAppearance(dark?0:WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS|WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        LinearLayout header=horizontal();header.setPadding(dp(14),dp(4),dp(10),dp(4));
        if(chat>=0)header.addView(button("‹",this::goBack),new LinearLayout.LayoutParams(dp(48),dp(48)));
        ImageView flag=new ImageView(this);flag.setImageResource(R.drawable.app_icon);flag.setContentDescription("Israel flag");header.addView(flag,new LinearLayout.LayoutParams(dp(35),dp(35)));
        TextView title=text(chat>=0?chatName:"SocialTap",21,ink);title.setTypeface(null,Typeface.BOLD);title.setPadding(dp(10),0,dp(6),0);title.setMaxLines(1);title.setEllipsize(TextUtils.TruncateAt.END);header.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));title.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(button("☰",this::settings),new LinearLayout.LayoutParams(dp(52),dp(48)));root.addView(header);
        View stripe=new View(this);stripe.setBackgroundColor(0xff2465ce);root.addView(stripe,new LinearLayout.LayoutParams(-1,dp(3)));
        status=text(api.connected()?"Connecting to your chats…":"Blue & White · Android",12,muted);status.setPadding(dp(18),dp(9),dp(18),dp(9));root.addView(status);
        body=vertical();root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        if(!api.connected())login();else if(chat<0)chatList();else conversation();
        root.requestApplyInsets();
    }
    private void login(){
        ScrollView scroll=new ScrollView(this);LinearLayout content=vertical();content.setPadding(dp(24),dp(30),dp(24),dp(24));scroll.addView(content);body.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        ImageView flag=new ImageView(this);flag.setImageResource(R.drawable.app_icon);content.addView(flag,new LinearLayout.LayoutParams(-1,dp(100)));space(content,24);
        TextView heading=text("Your conversations,\nwherever you are.",28,ink);heading.setTypeface(null,Typeface.BOLD);content.addView(heading);space(content,14);
        TextView detail=text("Connect your normal SocialTap account. Sign in with SocialTap or Google in your browser, then return here.",16,muted);detail.setLineSpacing(dp(3),1);content.addView(detail);space(content,24);
        content.addView(button(api.pending()?"Restart browser sign-in":"Connect with SocialTap / Google",this::connect));space(content,10);
        content.addView(button("Enable notifications",this::enableNotifications));content.addView(button("Test flag notification",this::testNotification));space(content,20);
        content.addView(text("Dark mode • Files • Background notifications\n\nThe browser may show the shared “SocialTap Blue & White Desktop” registration. This Android app uses the same registered native client.",13,muted));
        if(!api.status().isEmpty())status.setText(api.status());else if(api.pending())status.setText("Finish sign-in in your browser, then return here.");
    }
    private void connect(){
        status.setText("Opening secure sign-in…");
        worker.execute(()->{try{String url=api.beginAuth();main.post(()->{MessageService.start(this);try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(ActivityNotFoundException error){error("Install or enable a web browser to sign in.");}});}catch(Exception e){main.post(()->error(e.getMessage()));}});
    }
    private void chatList(){
        ScrollView scroll=new ScrollView(this);LinearLayout list=vertical();list.setPadding(dp(12),dp(10),dp(12),dp(12));scroll.addView(list);body.removeAllViews();body.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        TextView label=text("CONVERSATIONS",12,muted);label.setPadding(dp(8),0,0,dp(12));list.addView(label);
        addChat(list,0,"Global Chat","SocialTap community");
        for(int i=0;i<chats.length();i++){JSONObject room=chats.optJSONObject(i);if(room==null)continue;long id=room.optLong("id");String name=roomName(room);String detail="";JSONArray participants=room.optJSONArray("participants");if(participants!=null){for(int j=0;j<participants.length();j++){JSONObject p=participants.optJSONObject(j);if(p!=null&&p.optLong("id")!=api.selfId()){if(!detail.isEmpty())detail+=", ";detail+=p.optString("profile_username",p.optString("username","Member"));}}}addChat(list,id,name,detail.isEmpty()?"Open conversation":detail);}
        if(chats.length()==0){space(list,20);list.addView(text("Your member conversations will appear here after connecting.",14,muted));}
    }
    private String roomName(JSONObject room){String name=room.optString("name");if(!name.isEmpty()&&!name.equals("null"))return name;JSONArray people=room.optJSONArray("participants");List<String> names=new ArrayList<>();if(people!=null)for(int i=0;i<people.length();i++){JSONObject p=people.optJSONObject(i);if(p!=null&&p.optLong("id")!=api.selfId())names.add(p.optString("profile_username",p.optString("username","Member")));}return names.isEmpty()?"Saved messages":TextUtils.join(", ",names);}
    private void addChat(LinearLayout list,long id,String name,String detail){
        LinearLayout row=vertical();row.setPadding(dp(16),dp(15),dp(16),dp(15));row.setBackground(rounded(card,16));TextView title=text(name,18,ink);title.setTypeface(null,Typeface.BOLD);row.addView(title);TextView subtitle=text(detail,13,muted);subtitle.setMaxLines(1);subtitle.setEllipsize(TextUtils.TruncateAt.END);row.addView(subtitle);row.setOnClickListener(v->openChat(id,name));row.setContentDescription(name+", "+detail);list.addView(row,new LinearLayout.LayoutParams(-1,-2));space(list,9);
    }
    private void openChat(long id,String name){saveDraft();chat=id;chatName=name;messages=new JSONArray();readCursor=0;selectedFile=null;selectedName="";MessageService.visibleChat=id;rebuild();poll();}
    private void conversation(){
        messageScroll=new ScrollView(this);messageScroll.setFillViewport(true);messageList=vertical();messageList.setPadding(dp(12),dp(12),dp(12),dp(10));messageScroll.addView(messageList);body.addView(messageScroll,new LinearLayout.LayoutParams(-1,0,1));
        attachmentLabel=text("",12,accent);attachmentLabel.setPadding(dp(16),dp(4),dp(16),dp(4));attachmentLabel.setVisibility(View.GONE);body.addView(attachmentLabel);
        LinearLayout compose=horizontal();compose.setPadding(dp(8),dp(4),dp(8),dp(8));compose.addView(button("＋",this::chooseFile),new LinearLayout.LayoutParams(dp(48),dp(48)));
        composer=new EditText(this);composer.setTextColor(ink);composer.setHintTextColor(muted);composer.setHint("Message");composer.setTextSize(16);composer.setMaxLines(4);composer.setMinLines(1);composer.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);composer.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});composer.setBackground(rounded(card,18));composer.setPadding(dp(12),dp(10),dp(12),dp(10));composer.setText(api.prefs().getString("draft_"+chat,""));
        composer.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){MessageService.lastTouch=System.currentTimeMillis();}public void afterTextChanged(Editable e){}});
        compose.addView(composer,new LinearLayout.LayoutParams(0,-2,1));send=button("Send",this::sendMessage);compose.addView(send,new LinearLayout.LayoutParams(dp(70),dp(48)));body.addView(compose);showStagedFile();renderMessages();
    }
    private void showStagedFile(){if(attachmentLabel==null)return;attachmentLabel.setVisibility(selectedFile==null?View.GONE:View.VISIBLE);if(selectedFile!=null){attachmentLabel.setText(selectedName+" · tap to remove · press Send to share");attachmentLabel.setOnClickListener(v->{selectedFile=null;selectedName="";showStagedFile();});}}
    private void saveDraft(){if(composer!=null&&chat>=0)api.prefs().edit().putString("draft_"+chat,composer.getText().toString()).apply();}
    private void renderMessages(){
        if(messageList==null)return;String next=messages.toString()+api.selfId()+dark;if(next.equals(rendered))return;rendered=next;
        boolean bottom=messageList.getHeight()-messageScroll.getScrollY()-messageScroll.getHeight()<dp(120);messageList.removeAllViews();
        if(messages.length()==0){TextView hint=text("This is the start of the conversation.",14,muted);hint.setGravity(Gravity.CENTER);messageList.addView(hint);return;}
        for(int i=0;i<messages.length();i++){
            JSONObject message=messages.optJSONObject(i);if(message==null)continue;
            boolean mine=ChatRules.isMine(api.selfId(),api.selfName(),message.optLong("sender_user_id"),message.optString("profile_username",message.optString("username")));
            LinearLayout row=horizontal();row.setGravity(mine?Gravity.END:Gravity.START);LinearLayout bubble=vertical();bubble.setPadding(dp(13),dp(9),dp(13),dp(9));bubble.setBackground(rounded(mine?(dark?0xff234b85:0xffdce9ff):card,16));
            int width=Math.max(dp(200),Math.min(dp(520),getResources().getDisplayMetrics().widthPixels-dp(80)));
            TextView who=text(mine?"You":message.optString("username","SocialTap"),11,mine?(dark?0xffc4ddff:0xff295ba2):accent);who.setTypeface(null,Typeface.BOLD);who.setMaxWidth(width);bubble.addView(who);
            TextView content=text(message.optString("content"),16,ink);content.setTextIsSelectable(true);content.setMaxWidth(width);content.setPadding(0,dp(4),0,dp(5));bubble.addView(content);
            JSONObject attachment=message.optJSONObject("attachment");if(attachment!=null){String name=attachment.optString("filename","Attachment");boolean unavailable=attachment.optBoolean("expired")||attachment.optBoolean("removed")||attachment.optBoolean("restricted")||attachment.isNull("url");Button file=button("↗ "+name,()->attachmentOptions(attachment));file.setMaxWidth(width);file.setEnabled(!unavailable);if(unavailable)file.setText(name+" · unavailable");bubble.addView(file);}
            String time=message.optString("timestamp",message.optString("timestamp_iso",""));TextView stamp=text(time,10,muted);stamp.setGravity(Gravity.END);stamp.setMaxWidth(width);bubble.addView(stamp);
            row.addView(bubble,new LinearLayout.LayoutParams(-2,-2));LinearLayout.LayoutParams rowParams=new LinearLayout.LayoutParams(-1,-2);rowParams.bottomMargin=dp(10);messageList.addView(row,rowParams);
        }
        if(bottom||readCursor==0)messageScroll.post(()->messageScroll.fullScroll(View.FOCUS_DOWN));
    }
    private void poll(){
        if(polling||!resumed)return;
        if(wasConnected!=api.connected()){wasConnected=api.connected();profileChecked=false;lastChats=0;chat=-1;rebuild();}
        if(!api.connected()){if(api.pending())status.setText("Finish sign-in in your browser, then return here.");return;}
        polling=true;final long requested=chat;
        worker.execute(()->{
            try{
                if(!profileChecked){profileChecked=true;if(api.hasScope("account.read"))try{JSONObject result=(JSONObject)api.getJson("/api/account");JSONObject account=result.optJSONObject("account");if(account==null)account=result.optJSONObject("user");if(account==null)account=result.optJSONObject("profile");if(account==null)account=result;api.identity(account.optLong("id",account.optLong("user_id",account.optLong("userId"))),account.optString("username"));}catch(Exception ignored){}}
                JSONArray rooms=null;if(System.currentTimeMillis()-lastChats>60000||requested<0){rooms=(JSONArray)api.getJson("/api/chats");lastChats=System.currentTimeMillis();learnRooms(rooms);}
                JSONArray history=requested>=0?(JSONArray)api.getJson("/messages?chat_id="+requested):null;
                JSONArray freshRooms=rooms;
                main.post(()->{polling=false;if(isDestroyed())return;if(freshRooms!=null){chats=freshRooms;if(chat<0)chatList();}if(chat==requested&&history!=null){messages=history;renderMessages();if(resumed&&history.length()>0){long latest=history.optJSONObject(history.length()-1).optLong("id");if(latest>readCursor){readCursor=latest;worker.execute(()->{try{if(resumed&&chat==requested)api.postJson("/api/chat/read",new JSONObject().put("chat_id",requested).put("last_read_message_id",latest));}catch(Exception ignored){}});getSystemService(NotificationManager.class).cancel("chat:"+chat,2);}}}status.setText(api.status().isEmpty()?"Connected · "+api.selfName():api.status());});
            }catch(Exception e){main.post(()->{polling=false;if(!isDestroyed())status.setText(api.status().isEmpty()?"Connection interrupted · retrying…":api.status());});}
        });
    }
    private void learnRooms(JSONArray rooms) throws Exception {
        List<Set<Long>> members=new ArrayList<>();
        for(int i=0;i<rooms.length();i++){JSONObject room=rooms.getJSONObject(i);JSONArray people=room.optJSONArray("participants");Set<Long> ids=new HashSet<>();if(people!=null)for(int j=0;j<people.length();j++){long id=people.getJSONObject(j).optLong("id");if(id>0)ids.add(id);}members.add(ids);}
        if(api.selfId()==0){long id=ChatRules.uniqueMember(members);if(id>0){String name="";for(int i=0;i<rooms.length();i++){JSONArray people=rooms.getJSONObject(i).optJSONArray("participants");if(people!=null)for(int j=0;j<people.length();j++){JSONObject p=people.getJSONObject(j);if(p.optLong("id")==id)name=p.optString("profile_username",p.optString("username"));}}api.identity(id,name);}}
        SharedPreferences.Editor edit=api.prefs().edit();for(int i=0;i<rooms.length();i++){JSONObject room=rooms.getJSONObject(i);edit.putString("chat_name_"+room.optLong("id"),roomName(room));}edit.apply();
    }
    private void sendMessage(){
        if(sending||composer==null)return;String message=composer.getText().toString().trim();if(message.isEmpty()&&selectedFile==null)return;
        final long target=chat;final byte[] file=selectedFile;final String filename=selectedName;final String draft=composer.getText().toString();sending=true;send.setEnabled(false);status.setText(file==null?"Sending…":"Sending file…");
        worker.execute(()->{try{if(file==null)api.send(target,message);else api.upload(target,filename,file,message);api.prefs().edit().remove("draft_"+target).apply();main.post(()->{sending=false;if(chat==target&&composer!=null){if(composer.getText().toString().equals(draft))composer.setText("");selectedFile=null;selectedName="";attachmentLabel.setVisibility(View.GONE);send.setEnabled(true);}poll();});}catch(Exception e){main.post(()->{sending=false;if(send!=null)send.setEnabled(true);error(e.getMessage()+"\n\nYour draft is kept. If the connection failed while sending, check the chat before trying again.");});}});
    }
    private void chooseFile(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,40);}
    @Override public void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        if(request==40){final long target=chat;worker.execute(()->{try{String name="attachment";try(Cursor cursor=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE},null,null,null)){if(cursor!=null&&cursor.moveToFirst()){name=cursor.getString(0);if(!cursor.isNull(1)&&cursor.getLong(1)>Api.MAX_FILE)throw new IOException("Choose a file up to 10 MiB.");}}byte[] bytes;try(InputStream input=getContentResolver().openInputStream(uri)){bytes=Api.readLimited(input,Api.MAX_FILE);}if(bytes.length==0)throw new IOException("This file is empty.");String filename=ChatRules.filename(name);main.post(()->{if(chat!=target)return;selectedFile=bytes;selectedName=filename;attachmentLabel.setText(filename+" · tap to remove · press Send to share");attachmentLabel.setVisibility(View.VISIBLE);attachmentLabel.setOnClickListener(v->{selectedFile=null;selectedName="";attachmentLabel.setVisibility(View.GONE);});});}catch(Exception e){main.post(()->error(e.getMessage()));}});}
        if(request==41){byte[] bytes=pendingSave;pendingSave=null;if(bytes!=null)worker.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("Could not save this file.");out.write(bytes);main.post(()->Toast.makeText(this,"File saved",Toast.LENGTH_SHORT).show());}catch(Exception e){main.post(()->error(e.getMessage()));}});}
    }
    private void attachmentOptions(JSONObject attachment){new AlertDialog.Builder(this).setTitle(attachment.optString("filename","Attachment")).setItems(new String[]{"Open with an app","Save a copy"},(dialog,choice)->download(attachment,choice==0)).setNegativeButton("Cancel",null).show();}
    private void download(JSONObject attachment,boolean open){status.setText("Downloading attachment…");worker.execute(()->{try{byte[] bytes=api.attachment(attachment.getString("id"));String name=ChatRules.filename(attachment.optString("filename","attachment"));if(open){File dir=new File(getCacheDir(),"attachments");if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Could not prepare the file.");File file=new File(dir,UUID.randomUUID()+"_"+name);try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}Uri uri=new Uri.Builder().scheme("content").authority("socialtap.bluewhite.android.files").appendPath(file.getName()).build();main.post(()->{Intent intent=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,getContentResolver().getType(uri)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("Attachment",uri));try{startActivity(Intent.createChooser(intent,"Open attachment"));}catch(ActivityNotFoundException e){saveCopy(bytes,name);}});}else main.post(()->saveCopy(bytes,name));}catch(Exception e){main.post(()->error(e.getMessage()));}});}
    private void saveCopy(byte[] bytes,String name){pendingSave=bytes;Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(save,41);}
    private void settings(){
        String[] options={dark?"Use light mode":"Use dark mode","Enable / manage notifications","Test flag notification",api.prefs().getBoolean("background",true)?"Pause background connection":"Resume background connection","Reconnect with SocialTap / Google","Open SocialTap website","Disconnect this device"};
        new AlertDialog.Builder(this).setTitle("SocialTap settings").setItems(options,(dialog,which)->{if(which==0){saveDraft();dark=!dark;api.prefs().edit().putBoolean("dark",dark).apply();rebuild();}else if(which==1)enableNotifications();else if(which==2)testNotification();else if(which==3){boolean enabled=!api.prefs().getBoolean("background",true);api.prefs().edit().putBoolean("background",enabled).apply();if(enabled&&api.connected())MessageService.start(this);else stopService(new Intent(this,MessageService.class));Toast.makeText(this,enabled?"Background connection enabled":"Notifications pause when this screen closes",Toast.LENGTH_LONG).show();}else if(which==4)connect();else if(which==5)startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(ApiOrigin.VALUE)));else new AlertDialog.Builder(this).setTitle("Disconnect this device?").setMessage("This stops its notifications. Your chats remain on SocialTap.").setNegativeButton("Cancel",null).setPositiveButton("Disconnect",(d,w)->worker.execute(()->{try{api.disconnect();main.post(()->{stopService(new Intent(this,MessageService.class));chat=-1;rebuild();});}catch(Exception e){main.post(()->error("Could not revoke the connection. Try again when online."));}})).show();}).setNegativeButton("Close",null).show();
    }
    private void enableNotifications(){MessageService.channels(this);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},50);return;}startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
    private void testNotification(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},51);return;}boolean shown=MessageService.showMessage(this,-1,"SocialTap · notification test","Your Israel-flag notifications are ready",true);Toast.makeText(this,shown?"Test sent · check your notification panel":"Enable SocialTap notifications in phone settings",Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED){if(request==51)testNotification();else Toast.makeText(this,"Notifications enabled",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"You can enable notifications later in Settings",Toast.LENGTH_LONG).show();}
    private void error(String message){if(isFinishing()||isDestroyed())return;status.setText("Action needs attention");new AlertDialog.Builder(this).setTitle("SocialTap").setMessage(message==null?"Please try again.":message).setPositiveButton("OK",null).show();}
}
