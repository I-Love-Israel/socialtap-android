$ErrorActionPreference = 'Stop'
$toolsRoot = Join-Path $PSScriptRoot 'android-tools'
[xml]$repo = Get-Content (Join-Path $toolsRoot 'repository.xml')
$jdk = (Get-Content (Join-Path $toolsRoot 'jdk.json') -Raw | ConvertFrom-Json)[0].binary.package
function Fetch-Zip($url, $file, $checksum, $algorithm, $destination) {
    $zip = Join-Path $toolsRoot $file
    if (-not (Test-Path -LiteralPath $zip)) {
        & curl.exe --fail --location --silent --show-error $url --output $zip
        if ($LASTEXITCODE -ne 0) { throw "Download failed: $file" }
    }
    if ((Get-FileHash -LiteralPath $zip -Algorithm $algorithm).Hash.ToLower() -ne $checksum.ToLower()) { throw "Checksum mismatch: $file" }
    if (-not (Test-Path -LiteralPath $destination)) { Expand-Archive -LiteralPath $zip -DestinationPath $destination }
    Write-Output "Verified and unpacked $file"
}
Fetch-Zip $jdk.link 'jdk.zip' $jdk.checksum 'SHA256' (Join-Path $toolsRoot 'jdk')
foreach ($entry in @(@('platforms;android-36','platform-36_r02.zip','platform'),@('build-tools;36.0.0','build-tools_r36_windows.zip','build-tools'),@('platform-tools','platform-tools_r37.0.1-win.zip','platform-tools'))) {
    $package = $repo.DocumentElement.remotePackage | Where-Object { $_.path -eq $entry[0] }
    $archive = $package.archives.archive | Where-Object { $_.complete.url -eq $entry[1] }
    if (-not $archive) { throw "Official SDK package not found: $($entry[1])" }
    Fetch-Zip ('https://dl.google.com/android/repository/' + $entry[1]) $entry[1] ([string]$archive.complete.checksum) 'SHA1' (Join-Path $toolsRoot $entry[2])
}
