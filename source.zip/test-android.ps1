$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot 'socialtap-client/android'
$javaRoot = (Get-ChildItem (Join-Path $PSScriptRoot 'android-tools/jdk') -Directory | Select-Object -First 1).FullName
$classes = Join-Path $PSScriptRoot 'android-tests'
New-Item -ItemType Directory -Force -Path $classes | Out-Null
& (Join-Path $javaRoot 'bin/javac.exe') --release 8 -encoding UTF-8 -d $classes (Join-Path $project 'src/socialtap/bluewhite/android/ChatRules.java') (Join-Path $project 'src/socialtap/bluewhite/android/ApiOrigin.java') (Join-Path $project 'tests/ChatRulesTest.java')
if ($LASTEXITCODE -ne 0) { throw 'Test compilation failed' }
& (Join-Path $javaRoot 'bin/java.exe') -cp $classes socialtap.bluewhite.android.ChatRulesTest
if ($LASTEXITCODE -ne 0) { throw 'Android checks failed' }
